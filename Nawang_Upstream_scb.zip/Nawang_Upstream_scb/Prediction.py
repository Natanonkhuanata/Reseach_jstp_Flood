"""
     Prediction Model Upstream 3 hours 
     โมเดลนี้พยากรณ์ 3 ชั่วโมงล่วงหน้า 

     - การ Scaler ใช้ 2 ตัว คือ scaler_X สำหรับข้อมูลนำเข้า (input) ส่วน scaler_y สำหรับข้อมูลเป้าหมาย (target)
     - ข้อมูลที่นำเข้ามาต้องเเปลงเป็น shape (1 , 10 , 1 ) คือ 10 ชั่วโมงย้อนหลัง 1 ตัวแปร
     - ข้อมูลทดสอบ 10 ชั่วโมงย้อนหลัง โดยจะต้องเเปลงข้อมูลให้เป็น hours ถ้าข้อมูลที่ดึง api เข้ามาเป็น minutes 
       โดยใช้ code นี้  resample("H").interpolate(method = 'linear')
     - ตัวแปรที่นำมาใช้พยากรณ์ คือ Water_flow_rate  คือ  อัตราการไหลของน้ำ หน่วย m3/s
"""




import numpy as np
from tensorflow import keras
from keras.models import load_model
from keras.optimizers import Adam
from keras.losses import MeanSquaredError 
from keras.metrics import MeanAbsoluteError , RootMeanSquaredError
import joblib


# โหลดโมเดล
model = load_model("C:/Github/opencv/Reseach_jstp_Flood/Nawang_Upstream_scb/Model.h5")
model.compile(optimizer= Adam() , loss= MeanSquaredError() , metrics=[MeanAbsoluteError() , RootMeanSquaredError()])

# โหลด Scaler
scaler_X = joblib.load("C:/Github/opencv/Reseach_jstp_Flood/Nawang_Upstream_scb/scaler_X.pkl")
scaler_y = joblib.load("C:/Github/opencv/Reseach_jstp_Flood/Nawang_Upstream_scb/scaler_y.pkl")

# ข้อมูลทดสอบ 10 ชั่วโมงย้อนหลัง
Test = np.array([214.16 , 214.16 , 214.16 , 214.16 , 214.16 , 214.16 , 214.16 , 214.16 , 214.16 , 246.53])  

# Reshape เป็น 2D → (samples, features)
Test = Test.reshape(-1, 1)  

# Scaling ใช้ scaler_X สำหรับ input
Test_scaled = scaler_X.transform(Test)

# แปลงเป็น shape ที่ LSTM ต้องการ → (1, 10, 1)
Test_scaled = Test_scaled.reshape(1, 10, 1)

# พยากรณ์
y_pred = model.predict(Test_scaled)

# แปลงกลับเป็นค่าเดิม
y_pred_inverse = scaler_y.inverse_transform(y_pred)

print("ผลการพยากรณ์ :", y_pred_inverse[0])
